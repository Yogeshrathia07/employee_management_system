'use strict';
const PDFDocument = require('pdfkit');

const M        = 10;
const PW       = 595;
const PH       = 842;
const W        = PW - M * 2;   // 555
const X        = M;
const BLK      = '#000000';
const DRK      = '#1a1a1a';
const GRY      = '#555555';
const LGY      = '#888888';
const HBG      = '#f2f2f2';
const LBD      = 0.5;
const FOOTER_H = 24;

const CONF_TEXT =
  'Note: This document is the property of DHPE and is confidential. It must not be disclosed, ' +
  'shared, or transmitted to any person or firm not authorized by us. No part of this ' +
  'document may be copied, reproduced, or used in whole or in part without our prior written consent.';

function fmtDate(s) {
  if (!s) return '';
  const d = new Date(s);
  if (isNaN(d)) return s;
  return ('0'+d.getDate()).slice(-2)+'/'+('0'+(d.getMonth()+1)).slice(-2)+'/'+d.getFullYear();
}

function fmtINR(n) {
  return 'Rs. ' + Number(n||0).toLocaleString('en-IN', { minimumFractionDigits:2, maximumFractionDigits:2 });
}

function numWords(n) {
  const ones = ['','One','Two','Three','Four','Five','Six','Seven','Eight','Nine',
    'Ten','Eleven','Twelve','Thirteen','Fourteen','Fifteen','Sixteen','Seventeen','Eighteen','Nineteen'];
  const tens = ['','','Twenty','Thirty','Forty','Fifty','Sixty','Seventy','Eighty','Ninety'];
  function toWords(num) {
    if (num === 0) return '';
    if (num < 20)       return ones[num] + ' ';
    if (num < 100)      return tens[Math.floor(num/10)] + (num%10 ? ' '+ones[num%10] : '') + ' ';
    if (num < 1000)     return ones[Math.floor(num/100)] + ' Hundred ' + toWords(num%100);
    if (num < 100000)   return toWords(Math.floor(num/1000))    + 'Thousand ' + toWords(num%1000);
    if (num < 10000000) return toWords(Math.floor(num/100000))  + 'Lakh '     + toWords(num%100000);
    return               toWords(Math.floor(num/10000000)) + 'Crore ' + toWords(num%10000000);
  }
  const intPart = Math.floor(Math.abs(n));
  const decPart = Math.round((Math.abs(n) - intPart) * 100);
  let result = toWords(intPart).trim() + ' Rupees';
  if (decPart > 0) result += ' and ' + toWords(decPart).trim() + ' Paise';
  return 'Rupees ' + result + '.';
}

function pdfSafePart(value) {
  return String(value || '')
    .replace(/[\\/:*?"<>|]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/[^a-z0-9]+/gi, '-')
    .replace(/-+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function buildPdfFilename(parts) {
  const base = (parts || [])
    .map(pdfSafePart)
    .filter(Boolean)
    .join('-');
  return (base || 'document') + '.pdf';
}

function normalizeTaxRate(value) {
  const num = Number(value || 0);
  if (!Number.isFinite(num) || num <= 0.0001) return 0;
  return Math.round(num * 10000) / 10000;
}

function uniquePositiveRates(values) {
  return Array.from(
    new Set((values || []).map(normalizeTaxRate).filter(rate => rate > 0))
  ).sort((a, b) => a - b);
}

function formatTaxRate(rate) {
  const normalized = normalizeTaxRate(rate);
  if (!normalized) return '0%';
  if (Math.abs(normalized - Math.round(normalized)) < 0.0001) {
    return Math.round(normalized) + '%';
  }
  return parseFloat(normalized.toFixed(2)) + '%';
}

function collectItemTaxRates(record) {
  const items = Array.isArray(record && record.items) ? record.items : [];
  return uniquePositiveRates(items.map(item => Number(item && item.taxRate || 0)));
}

function hasValue(value) {
  return !(value === null || value === undefined || (typeof value === 'string' && value.trim() === ''));
}

function providedNumber(value) {
  if (!hasValue(value)) return null;
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
}

function firstProvidedNumber() {
  for (let i = 0; i < arguments.length; i += 1) {
    const num = providedNumber(arguments[i]);
    if (num !== null) return num;
  }
  return null;
}

function firstTextValue() {
  for (let i = 0; i < arguments.length; i += 1) {
    const value = arguments[i];
    if (typeof value === 'string' && value.trim()) return value.trim();
  }
  return '';
}

function roundMoney(value) {
  return Math.round((Number(value || 0) + Number.EPSILON) * 100) / 100;
}

function normalizeAccountItem(item, taxModeHint) {
  const source = item || {};
  const quantity = firstProvidedNumber(source.quantity, source.qty, 0) || 0;
  const unitPrice = firstProvidedNumber(source.unitPrice, source.rate, 0) || 0;
  const discount = firstProvidedNumber(source.discount, 0) || 0;
  const taxRate = firstProvidedNumber(source.taxRate, source.taxPercent, 0) || 0;
  const computedTaxable = roundMoney(quantity * unitPrice * (1 - (discount / 100)));
  const taxableAmount = roundMoney(firstProvidedNumber(source.taxableAmount, computedTaxable) || 0);
  let cgst = firstProvidedNumber(source.cgst);
  let sgst = firstProvidedNumber(source.sgst);
  let igst = firstProvidedNumber(source.igst);
  let taxAmount = firstProvidedNumber(source.taxAmount);
  const inferredMode = taxModeHint === 'igst' || taxModeHint === 'split'
    ? taxModeHint
    : ((igst || 0) > 0.004 && (cgst || 0) <= 0.004 && (sgst || 0) <= 0.004 ? 'igst' : 'split');

  if (taxAmount === null) {
    const summedTax = roundMoney((cgst || 0) + (sgst || 0) + (igst || 0));
    taxAmount = summedTax > 0.004 ? summedTax : null;
  }

  if (taxAmount !== null && cgst === null && sgst === null && igst === null) {
    if (inferredMode === 'igst') {
      igst = taxAmount;
      cgst = 0;
      sgst = 0;
    } else {
      cgst = roundMoney(taxAmount / 2);
      sgst = roundMoney(taxAmount / 2);
      igst = 0;
    }
  }

  if (taxAmount === null && taxRate > 0.0001 && taxableAmount > 0.0001) {
    taxAmount = roundMoney(taxableAmount * taxRate / 100);
    if (inferredMode === 'igst') {
      igst = taxAmount;
      cgst = 0;
      sgst = 0;
    } else {
      cgst = roundMoney(taxAmount / 2);
      sgst = roundMoney(taxAmount / 2);
      igst = 0;
    }
  }

  cgst = roundMoney(cgst || 0);
  sgst = roundMoney(sgst || 0);
  igst = roundMoney(igst || 0);
  taxAmount = roundMoney(taxAmount === null ? (cgst + sgst + igst) : taxAmount);

  const itemTotal = roundMoney(firstProvidedNumber(source.itemTotal, source.total, taxableAmount + taxAmount) || 0);
  const code = firstTextValue(source.itemCode, source.code);
  const description = firstTextValue(source.name, source.description, source.itemName);
  const hsnCode = firstTextValue(source.hsnCode, source.hsnSac, source.hsn);
  const unit = firstTextValue(source.unit);

  return {
    itemCode: code,
    code: code,
    name: description,
    description: description,
    itemName: description,
    hsnCode: hsnCode,
    hsnSac: hsnCode,
    hsn: hsnCode,
    unit: unit,
    quantity: quantity,
    qty: quantity,
    unitPrice: unitPrice,
    rate: unitPrice,
    discount: discount,
    taxRate: roundMoney(taxRate),
    taxPercent: roundMoney(taxRate),
    taxableAmount: taxableAmount,
    cgst: cgst,
    sgst: sgst,
    igst: igst,
    taxAmount: taxAmount,
    itemTotal: itemTotal,
  };
}

function normalizeAccountItems(items, taxModeHint) {
  return (Array.isArray(items) ? items : []).map(item => normalizeAccountItem(item, taxModeHint));
}

function deriveItemTotals(items) {
  return (Array.isArray(items) ? items : []).reduce((acc, item) => {
    acc.subtotal += roundMoney(item && item.taxableAmount || 0);
    acc.totalCgst += roundMoney(item && item.cgst || 0);
    acc.totalSgst += roundMoney(item && item.sgst || 0);
    acc.totalIgst += roundMoney(item && item.igst || 0);
    return acc;
  }, { subtotal: 0, totalCgst: 0, totalSgst: 0, totalIgst: 0 });
}

function buildTaxSummaryLabels(record, mode) {
  const itemRates = collectItemTaxRates(record);
  const splitRates = uniquePositiveRates(
    (record ? [record.sgstRate, record.cgstRate] : []).concat(
      itemRates.length ? itemRates.map(rate => rate / 2) : []
    )
  );
  const igstRates = uniquePositiveRates(
    (record ? [Number(record.sgstRate || 0) + Number(record.cgstRate || 0)] : []).concat(itemRates)
  );
  const formatList = rates => rates.map(formatTaxRate).join(', ');
  return {
    cgst: splitRates.length ? 'CGST @ ' + formatList(splitRates) : 'CGST',
    sgst: splitRates.length ? 'SGST @ ' + formatList(splitRates) : 'SGST',
    igst: mode === 'igst' && igstRates.length ? 'IGST @ ' + formatList(igstRates) : 'IGST',
  };
}

function createDoc() {
  const doc = new PDFDocument({ margin:0, size:'A4', bufferPages:true });

  function hLine(y, x1, x2, lw) {
    doc.moveTo(x1!==undefined?x1:X, y).lineTo(x2!==undefined?x2:X+W, y)
       .lineWidth(lw||LBD).strokeColor(BLK).stroke();
  }
  function vLine(x, y1, y2, lw) {
    doc.moveTo(x,y1).lineTo(x,y2).lineWidth(lw||LBD).strokeColor(BLK).stroke();
  }
  function box(x, y, w, h, lw) {
    doc.rect(x,y,w,h).lineWidth(lw||LBD).strokeColor(BLK).stroke();
  }
  function fillBox(x, y, w, h, fill) {
    doc.rect(x,y,w,h).fillColor(fill).fill();
  }
  function txt(text, x, y, w, opts) {
    opts = opts || {};
    doc.fontSize(opts.size||8).font(opts.bold?'Helvetica-Bold':'Helvetica')
       .fillColor(opts.color||DRK)
       .text(String(text||''), x, y, {
         width:w, align:opts.align||'left',
         lineGap:opts.lineGap!==undefined?opts.lineGap:0.5,
         ellipsis:opts.ellipsis!==undefined?opts.ellipsis:false,
         lineBreak:opts.lineBreak!==undefined?opts.lineBreak:true,
         height:opts.height,
       });
  }
  function txtH(text, w, size, bold) {
    doc.fontSize(size||8).font(bold?'Helvetica-Bold':'Helvetica');
    return doc.heightOfString(String(text||''), { width:w, lineGap:0.5 });
  }
  function checkPage(y, needed) {
    if (y + needed > PH - M - FOOTER_H) { doc.addPage(); return M; }
    return y;
  }

  return { doc, hLine, vLine, box, fillBox, txt, txtH, checkPage };
}

function addFooters(doc, options) {
  options = options || {};
  const infoText = String(options.infoText || '').trim();
  const infoOnAllPages = options.infoOnAllPages === true;
  const range = doc.bufferedPageRange();
  const total = range.count;
  if (!total) return;
  for (let pageIndex = 0; pageIndex < total; pageIndex += 1) {
    doc.switchToPage(range.start + pageIndex);
    const footerY = PH - M - FOOTER_H + 3;
    const pageLabelW = 60;
    const sepX = X + W - pageLabelW - 8;
    const noteW = sepX - X - 6;
    const showInfo = !!infoText && (infoOnAllPages || pageIndex === total - 1);

    doc.moveTo(X, footerY)
      .lineTo(X + W, footerY)
      .lineWidth(0.3)
      .strokeColor('#d7dce5')
      .stroke();

    doc.moveTo(sepX, footerY + 2)
      .lineTo(sepX, footerY + FOOTER_H - 8)
      .lineWidth(0.3)
      .strokeColor('#d7dce5')
      .stroke();

    if (showInfo) {
      doc.fontSize(5.5).font('Helvetica-Oblique').fillColor('#8a94a3')
        .text(infoText, X + 4, footerY + 1, {
          width: noteW,
          align: 'left',
          lineGap: 0,
        });
    }

    doc.fontSize(showInfo ? 4.9 : 5.2).font('Helvetica').fillColor('#7c8797')
      .text(CONF_TEXT, X + 4, showInfo ? footerY + 8 : footerY + 3, {
        width: noteW,
        align: 'center',
        lineGap: showInfo ? 0.1 : 0.15,
      });

    doc.fontSize(5.8).font('Helvetica').fillColor('#7c8797')
      .text(`Page ${pageIndex + 1} of ${total}`, sepX + 4, showInfo ? footerY + 7 : footerY + 4, {
        width: pageLabelW,
        align: 'right',
        lineGap: 0,
      });
  }
}

// ── Standard header box: company info (left) | doc meta (right) ───────────────
function drawHeader(h, metaRight, sellerLines) {
  const { doc, hLine, vLine, box, fillBox, txt, txtH } = h;
  const HW = W / 2;
  const RX = X + HW;

  let hBoxH = 8;
  sellerLines.forEach((l, i) => {
    hBoxH += txtH(l, HW - 14, i===0?12:7.5, i===0) + 1.5;
  });
  const hBoxHR = metaRight.reduce((s,l,i) => s + txtH(l, HW-12, i===0?8.5:7.5, i===0) + 1.5, 5);
  const headerH = Math.max(hBoxH, hBoxHR) + 5;

  box(X, M, W, headerH, LBD);
  vLine(X+HW, M, M+headerH, LBD);

  let ly = M + 5;
  sellerLines.forEach((line, i) => {
    if (!line) return;
    txt(line, X+5, ly, HW-10, { size:i===0?12:7.5, bold:i===0, color:BLK, lineGap:0.5 });
    ly = doc.y + (i===0?2:1);
  });

  let ry = M + 5;
  metaRight.forEach((line, i) => {
    if (!line) return;
    txt(line, RX+4, ry, HW-10, { size:i===0?8.5:7.5, bold:i===0, color:BLK, align:'right', lineGap:0.5 });
    ry = doc.y + 1;
  });

  return M + headerH;
}

// ── Standard section label row ────────────────────────────────────────────────
function drawSectionLabel(h, label, y) {
  const { fillBox, box, txt } = h;
  fillBox(X, y, W, 11, HBG);
  box(X, y, W, 11, LBD);
  txt(label, X+5, y+2, W-10, { size:7.5, bold:true, color:BLK });
  return y + 11;
}

// ── Signature block (bank left + authorized right) ────────────────────────────
function drawSignature(h, y, companyName, bankLines) {
  const { fillBox, box, vLine, hLine, txt } = h;
  const HW = W / 2;
  const RX = X + HW;
  const bankH = bankLines.length * 10 + 17;

  fillBox(X, y, W, 11, HBG);
  box(X, y, W, bankH, LBD);
  vLine(X+HW, y, y+bankH, LBD);
  hLine(y+11, X, X+W, LBD);

  txt('Bank Account Details:', X+5, y+2, HW-10, { size:7.5, bold:true, color:BLK });
  txt('Authorized Signature', RX+5, y+2, HW-10, { size:7.5, bold:true, color:BLK, align:'right' });

  let bky = y + 14;
  bankLines.forEach(([label, val]) => {
    txt(label+' '+val, X+5, bky, HW-10, { size:7.5, color:BLK });
    bky += 10;
  });

  txt('For '+(companyName||''), RX+5, y+bankH-19, HW-10, { size:7.5, bold:true, color:BLK, align:'right' });
  txt('Authorized Signatory',   RX+5, y+bankH-10, HW-10, { size:7.5, color:BLK, align:'right' });

  return y + bankH;
}

module.exports = {
  M, PW, PH, W, X, BLK, DRK, GRY, LGY, HBG, LBD, FOOTER_H,
  fmtDate, fmtINR, numWords, pdfSafePart, buildPdfFilename, buildTaxSummaryLabels, createDoc, addFooters,
  roundMoney, normalizeAccountItems, deriveItemTotals,
  drawHeader, drawSectionLabel, drawSignature,
};
